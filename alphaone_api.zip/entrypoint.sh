export NODE_ENV=production
export NODE_TLS_REJECT_UNAUTHORIZED=0
./alphaone_api http