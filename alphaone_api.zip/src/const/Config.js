const net = {
  mainNet: {
    id: 241,
    wss: 'wss:///node.v1.riochain.io/ws'
  },
  testNet: {
    id: 221,
    wss: 'wss:///node.v1.staging.riochain.io/ws'
  }
}

const getNet = () => {
  return process.env.net ? net[`${process.env.net}`] : net.testNet
}

module.exports = {
  getNet
}
