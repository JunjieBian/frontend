const apollo = require('ctrip-apollo')
const Props = require('../../props/Index')

const app = apollo({
  host: Props.getProp('apollo.meta'),
  appId: Props.getProp('appId'),
  enableFetch: true,
  fetchTimeout: 3 * 60 * 1000,
  cachePath: `/opt/data/config-cache/`
})

const namespace = app.namespace('application','JSON')
  .on('change', ({
    key,
    oldValue,
    newValue
  }) => {
    Props.addProps(key, newValue)
  })

const load = async () => {
  await namespace.ready().then(() => {
    let configs = namespace.config()
    for (let e in configs) {
      Props.addProps(e, configs[e])
    }
    
  })
}
module.exports = {
  load
}
