const apollo = require('ctrip-apollo')
const Props = require('../../props/Index')

const { logger } = require('../../logger/Index')

const app = apollo({
  host: process.env.APOLLO_META
    ? process.env.APOLLO_META.includes(',') ? process.env.APOLLO_META.split(',')[0] : process.env.APOLLO_META
    : Props.getProp('apollo.meta').includes(',') ? Props.getProp('apollo.meta').split(',')[0] : Props.getProp('apollo.meta'),
  appId: process.env.APP_ID ? process.env.APP_ID : Props.getProp('appId'),
  enableFetch: true,
  fetchTimeout: 3 * 60 * 1000,
  cachePath: '/opt/data/config-cache/'
})

const namespace = app.namespace(process.env.productId ? process.env.productId : 'public', 'JSON')
  .on('change', ({
    key,
    oldValue,
    newValue
  }) => {
    Props.addProps(key, newValue)
  })

const load = async () => {
  logger.info('loading apollo configs...')
  await namespace.ready().then(() => {
    const configs = namespace.config()
    for (const e in configs) {
      Props.addProps(e, configs[e])
    }
    logger.info('loading apollo configs finished...')
  }).catch(err => {
    logger.error(err)
    process.exit(1)
  })
}
module.exports = {
  load
}
