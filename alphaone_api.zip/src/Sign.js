const { stringToU8a, u8aToHex } = require('@polkadot/util')
const Account = require('./Account')

const { logger } = require('./logger/Index')

const signByMnemonic = (msg, mnemonic, username, key) => {
  return Account.getAcctByMnemonic(username, mnemonic, key)
    .then(pair => {
      const message = stringToU8a(msg)
      let signature = pair.sign(message)
      const isValid = pair.verify(message, signature)
      if (isValid) {
        signature = u8aToHex(signature)
        return Promise.resolve(signature)
      }
      return Promise.reject(new Error('签名错误'))
    }).catch(er => {
      logger.error(er)
      return Promise.reject(new Error('签名错误'))
    })
}

const signByMnemonicSync = async (msg, mnemonic, username, key) => {
  const pair = await Account.getAcctByMnemonic(username, mnemonic, key).catch(er => {
    return Promise.reject(new Error('签名错误'))
  })
  const message = stringToU8a(msg)
  let signature = pair.sign(message)
  const isValid = pair.verify(message, signature)
  if (isValid) {
    signature = u8aToHex(signature)
    return Promise.resolve(signature)
  }
  return Promise.reject(new Error('签名错误'))
}

module.exports = {
  signByMnemonic,
  signByMnemonicSync
}
