const path = require('path')
const propertiesReader = require('properties-reader')
const properties = propertiesReader(path.join(__dirname, '../application.properties'))

const getProp = (key) => properties.get(key)
const getAll = () => properties.getAllProperties()

module.exports = {
  getProp,
  getAll
}
