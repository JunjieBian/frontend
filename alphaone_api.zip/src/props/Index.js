const path = require('path')
const propertiesReader = require('properties-reader')
const properties = propertiesReader(path.join(__dirname, '../application.properties'))

const getProp = (key) => properties.get(key)
const getAll = () => properties.getAllProperties()
const addProps = (key, value) => properties.set(key, value)

module.exports = {
  getProp,
  getAll,
  addProps
}
