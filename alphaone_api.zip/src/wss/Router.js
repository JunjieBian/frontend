const aes256 = require('aes256')
const Props = require('../props/Index')
const ResBody = require('../model/ResBody')
const ReqBody = require('../model/ReqBody')

const { logger } = require('../logger/Index')
const Sign = require('../service/alphaone/Sign')

const errHandler = (err, ws) => {
  logger.error('err.stack = ', err.stack)
  ws.send(JSON.stringify(ResBody.DEFAULT_ERR(err.message)))
}

const actionDispatch = (message, ws) => {
  try {
    const reqBody = Object.assign(new ReqBody(), JSON.parse(message))
    if (reqBody.action === 'sign') {
      const {
        mnemonic,
        userName,
        message,
        acctHash
      } = JSON.parse(aes256.decrypt(Props.getProp(reqBody.agent + '.aes.key'), reqBody.body))
      Sign.signByMnemonic(message, mnemonic, userName, acctHash).then(signature => {
        return ws.send(JSON.stringify(ResBody.DEFAULT_OK({ sig: signature })))
      }).catch(er => errHandler(er, ws))
    }
  } catch (err) {
    logger.error(err)
  }
}

module.exports = {
  actionDispatch
}
