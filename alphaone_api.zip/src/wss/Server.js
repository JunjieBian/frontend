const WebSocket = require('ws')

const { logger } = require('../logger/Index')
const Router = require('./Router')

const init = (port = 8080) => {
  const wss = new WebSocket.Server({
    port: port,
    server: 'socket.Server',
    path: '/wss'
  })
  wss.on('connection', function connection (ws) {
    ws.on('message', function incoming (message) {
      logger.info('received: %s', message)
      Router.actionDispatch(message, ws)
    })
    ws.send('connection successfull...')
  })
}

module.exports = {
  init
}
