const WebSocket = require('ws')
const ReqBody = require('../model/ReqBody')

const { logger } = require('./logger/Index')
const ws = new WebSocket('ws://localhost:3000/wss')

ws.on('open', function open () {
  const reqBody = new ReqBody('sign',
    'BTnayciFdJsWVIxpcMKjAmWK1iBtqecteqeT6nbVxbTTlO6N+mC4aUg60ROXDA9WfWUX7WmXS7eKLavrVZ08G7f5vUnvzpXg8+UE0iROjZs4/Ufi+pspbLVFF+ydZOjb/EggcI/soqQm5Zgq6AYKoE3TI++aXEGnsnF7Zg0jnw67GxtHw8zfyM4u5ll+wkc6A0ui00UF21LGonPSYEMV+r+OdXvc3OQiIgulslmmo8l+PTr7KwFbow0K5WTk/dUHjsdV7/umsVA=',
    'B01')
  for (let i = 0; i < 10; i++) { ws.send(JSON.stringify(reqBody)) }
})

ws.on('message', function incoming (data) {
  logger.info(data)
})
