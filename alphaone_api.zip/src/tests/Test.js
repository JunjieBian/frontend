const Md5 = require('md5')
const Sign = require('../Sign')
const { uuid } = require('uuidv4')
const gitCommitInfo = require('git-commit-info')
const { logger } = require('../logger/Index')
const aes256 = require('aes256')
const Props = require('../props/Index')
const dateFormat = require('dateformat')
const os = require('os')
const worker = require('worker_threads')

const mnemonic = 'mandate media town disagree sort skill mother ginger surround scrap ethics lady'
const userNme = 'Adley'

const acctHash = Md5(userNme + mnemonic)

logger.info(typeof '' === 'object')

const reqId = uuid()
console.log(uuid().replace(/-/g,''))


const body = {"mnemonic":"mandate media town disagree sort skill mother ginger surround scrap ethics lady", "userName": "Adley","message":"test message","acctHash":"03d1ee15373de2c4084ac8caac5e9364"}

console.log(aes256.encrypt(Props.getProp('B01.aes.key'), JSON.stringify(body)))


let up = process.uptime() * 1000
let n = Date.now()

console.log(process.cpuUsage(), process.uptime(),dateFormat(new Date(n - up),'yyyy-mm-dd HH:MM:ss'))
console.log(os.totalmem(), os.freemem(), os.cpus().length, os.networkInterfaces())
console.log(process.hrtime())

const secNSec2ms = (secNSec) => {
  if (Array.isArray(secNSec)) { 
    return secNSec[0] * 1000 + secNSec[1] / 1000000; 
  }
  return secNSec / 1000; 
}
const getCpuLoad = () => {
  let startTime  = process.hrtime()
  let startUsage = process.cpuUsage()

  // spin the CPU for 500 milliseconds
  let now = Date.now()
  do {} while (Date.now() - now < 500)

  let elapTime = process.hrtime(startTime)
  let elapUsage = process.cpuUsage(startUsage)

  let elapTimeMS = secNSec2ms(elapTime)
  let elapUserMS = secNSec2ms(elapUsage.user)
  let elapSystMS = secNSec2ms(elapUsage.system)
  return Math.round((elapUserMS + elapSystMS) / elapTimeMS)
}
