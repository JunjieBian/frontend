const Md5 = require('md5')
const Account = require('../service/eth/Account')
const Sign = require('../service/eth/Sign')
const ethers = require('ethers')
const aes256 = require('aes256')
const Props = require('../props/Index')

const mnemonic = 'ill portion burger cherry supreme magic clarify limit shoot horror panda check'
const userNme = 'alink123'

let acctHash = Md5(userNme + mnemonic)

// console.log(Account.getAcctByMnemonicSync(mnemonic, acctHash))

// Account.getAcctByMnemonicAsync(mnemonic, acctHash).then(wallet => {
//   console.log('wallet= ', wallet)
// })

const provider = new ethers.providers.JsonRpcProvider()
provider.listAccounts().then(d => {
  console.log(d)
})

const keyFile = '{"address":"412ee88fb7e066bc3f40a0c4cfae8d2bc0ee81d0","crypto":{"cipher":"aes-128-ctr","ciphertext":"5a079dec173a725db6f7c56b39cf4170261c162b9632cbade4652422081a305f","cipherparams":{"iv":"3622601e40e3c56d867840f37a9d7820"},"kdf":"scrypt","kdfparams":{"dklen":32,"n":262144,"p":1,"r":8,"salt":"295f2d3455bb80d9ae5bfd64a7b2b6aecca22a10f5e971350b56b85f4f2a6075"},"mac":"66517e37ddfb446de672f341bce9d175c2d1bb540936e628ed825af3581fea81"},"id":"30aac078-e7c8-4689-97a0-74e9d5324f0e","version":3}'
const pwd = 'alink123'
ethers.Wallet.fromEncryptedJson(keyFile, pwd).then(w => {
  console.log('privateKey', w._signingKey().privateKey)
}).catch(er => {
  console.error(er)
})

const privateKey = '0xb359d045000f51fad1a1626b5465a8e8a6228467824a91e3bc6e864e91e9542e'
new ethers.Wallet(privateKey)
  .getAddress().then(a => {
    console.log('from key = ', a)
  })

acctHash = Md5(userNme + privateKey)
Account.getAcctByKeyAsync(privateKey, acctHash, provider).then(w => {
  console.log('getAcctByKeyAsync', w)
})

const contractAddress = '0x1c6D20e5D26E41dC1Fcd8F2007a0D47Ed8a612d3'
const data = {
  methodName: 'store',
  methodArgs: ['t1', 't2', 't3', 't4']
}
Sign.signAndBroadCastSync(data, privateKey, contractAddress, acctHash).then(t => {
  console.info('t = ', t)
}).catch(er => {
  console.error(er)
})

const body = {
  privateKey: privateKey,
  contractAddress: contractAddress,
  acctHash: acctHash,
  message: data
}
console.log('body', aes256.encrypt(Props.getProp('B01.aes.key'), JSON.stringify(body)))
