require('./props/Index')
const HttpServer = require('./http/Server')
const WsServer = require('./wss/Server')
const { logger } = require('./logger/Index')

const APP = () => {
  const args = [...process.argv]
  logger.info(args)
  let port
  try {
    if (args.length >= 4) {
      process.env.net = args[3]
    }
    if (args.length >= 5) {
      port = args[4]
    }
    if (args[2].toUpperCase() === 'HTTP') {
      return HttpServer.init(port)
    }
    if (args[2].toUpperCase() === 'WSS') {
    // 待开发
      return WsServer.init(port)
    }
  } catch (err) {
    logger.error('用法： npm run http | wss')
  }
}

APP()
