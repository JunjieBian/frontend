'use strict'
require('./props/Index')
const Apollo = require('./config/apollo/Index')
const HttpServer = require('./http/Server')
const WsServer = require('./wss/Server')
const { logger } = require('./logger/Index')

const APP = () => {
  const args = [...process.argv]
  logger.info(args)
  let port
  try {
    if (args.length >= 4) {
      port = args[3]
    }
    Apollo.load()
    if (args[2].toUpperCase() === 'HTTP') {
      return HttpServer.init(port)
    }
    if (args[2].toUpperCase() === 'WSS') {
    // 待开发
      return WsServer.init(port)
    }
  } catch (err) {
    logger.error(err)
    logger.warn(`用法： npm run (http | wss) [port]
      默认： npm run http 8080
    `)
  }
}

APP()
