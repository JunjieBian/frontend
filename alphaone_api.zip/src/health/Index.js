// const Sysinfo = require('../model/Sysinfo')
const secNSec2ms = (secNSec) => {
  if (Array.isArray(secNSec)) {
    return secNSec[0] * 1000 + secNSec[1] / 1000000
  }
  return secNSec / 1000
}
const getCpuLoad = () => {
  const startTime = process.hrtime()
  const startUsage = process.cpuUsage()

  // spin the CPU for 500 milliseconds
  const now = Date.now()
  do {
    continue
  } while (Date.now() - now < 500)

  const elapTime = process.hrtime(startTime)
  const elapUsage = process.cpuUsage(startUsage)

  const elapTimeMS = secNSec2ms(elapTime)
  const elapUserMS = secNSec2ms(elapUsage.user)
  const elapSystMS = secNSec2ms(elapUsage.system)
  return Math.round((elapUserMS + elapSystMS) / elapTimeMS)
}

module.exports = {
  getCpuLoad
}
