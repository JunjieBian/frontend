module.exports = class Sysinfo {
  get availableProcessors () {
    return this.availableProcessors
  }

  get committedVirualMemorySize () {
    return this.committedVirualMemorySize
  }

  get freePhysicalMemorySize () {
    return this.freePhysicalMemorySize
  }

  get freeSwapSpaceSize () {
    return this.freeSwapSpaceSize
  }

  get heapUsage () {
    return this.heapUsage
  }

  get ip () {
    return this.ip
  }

  get nonHeapUsage () {
    return this.nonHeapUsage
  }

  get processCpuLoad () {
    return this.processCpuLoad
  }

  get processCpuTime () {
    return this.processCpuTime
  }

  get startTime () {
    return this.startTime
  }

  get systemCpuLoad () {
    return this.systemCpuLoad
  }

  get threadCount () {
    return this.threadCount
  }

  get timeZone () {
    return this.timeZone
  }

  get totalPhysicalMemorySize () {
    return this.totalPhysicalMemorySize
  }

  get totalSwapSpaceSize () {
    return this.totalSwapSpaceSize
  }

  get upTime () {
    return this.upTime
  }

  set availableProcessors (availableProcessors) {
    this.availableProcessors = availableProcessors
    return this
  }

  set committedVirualMemorySize (committedVirualMemorySize) {
    this.committedVirualMemorySize = committedVirualMemorySize
    return this
  }

  set freePhysicalMemorySize (freePhysicalMemorySize) {
    this.freePhysicalMemorySize = freePhysicalMemorySize
    return this
  }

  set freeSwapSpaceSize (freeSwapSpaceSize) {
    this.freeSwapSpaceSize = freeSwapSpaceSize
    return this
  }

  set heapUsage (heapUsage) {
    this.heapUsage = heapUsage
    return this
  }

  set ip (ip) {
    this.ip = ip
    return this
  }

  set nonHeapUsage (nonHeapUsage) {
    this.nonHeapUsage = nonHeapUsage
    return this
  }

  set processCpuLoad (processCpuLoad) {
    this.processCpuLoad = processCpuLoad
    return this
  }

  set processCpuTime (processCpuTime) {
    this.processCpuTime = processCpuTime
    return this
  }

  set startTime (startTime) {
    this.startTime = startTime
    return this
  }

  set systemCpuLoad (systemCpuLoad) {
    this.systemCpuLoad = systemCpuLoad
    return this
  }

  set threadCount (threadCount) {
    this.threadCount = threadCount
    return this
  }

  set timeZone (timeZone) {
    this.timeZone = timeZone
    return this
  }

  set totalPhysicalMemorySize (totalPhysicalMemorySize) {
    this.totalPhysicalMemorySize = totalPhysicalMemorySize
    return this
  }

  set totalSwapSpaceSize (totalSwapSpaceSize) {
    this.totalSwapSpaceSize = totalSwapSpaceSize
    return this
  }

  set upTime (upTime) {
    this.upTime = upTime
    return this
  }
}
