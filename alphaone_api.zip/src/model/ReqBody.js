const { uuid } = require('uuidv4')

module.exports = class ReqBody {
  constructor (action, body = {}, agent = '', authPwd = '', requrestId = uuid().replace(/-/g, '')) {
    this.action = action
    this.requrestId = requrestId
    this.agent = agent
    this.authPwd = authPwd
    this.body = body
  }
}
