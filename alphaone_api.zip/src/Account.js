const { Keyring } = require('@polkadot/keyring')
const { mnemonicGenerate, cryptoWaitReady } = require('@polkadot/util-crypto')
const Store = require('./store/Index')
const Config = require('./const/Config')

const getAcctByMnemonic = async (userName, mnemonic, key, type = 'sr25519') => {
  if (Store.acctExist(key)) {
    return Store.getAcct(key)
  } else {
    await cryptoWaitReady()
    const keyring = new Keyring({ type: type, ss58Format: Config.getNet().id })
    const pair = keyring.addFromUri(mnemonic, { name: userName }, type)
    Store.saveAcct(key, pair)
    return pair
  }
}

const createAcctByMnemonic = async (userName, type = 'sr25519') => {
  await cryptoWaitReady()
  const keyring = new Keyring({ type: type, ss58Format: Config.getNet().id })
  const mnemonic = mnemonicGenerate()
  console.log('mnemonic', mnemonic)
  const pair = keyring.addFromUri(mnemonic, { name: userName }, type)
  return pair
}

const removePair = async (address, type = 'sr25519') => {
  await cryptoWaitReady()
  const keyring = new Keyring({ type: type, ss58Format: Config.getNet().id })
  keyring.removePair(address)
}

module.exports = {
  createAcctByMnemonic,
  removePair,
  getAcctByMnemonic
}
