const express = require('express')
const Router = require('./Router')
const httpServer = express()
const bodyParser = require('body-parser')
const { logger } = require('../logger/Index')
const ResBody = require('../model/ResBody')

const errHandler = (err, res) => {
  logger.error('err.stack = ', err.stack)
  res.status(500).json(ResBody.DEFAULT_ERR(err.message))
}

const init = (port = 8080) => {
  httpServer.use(bodyParser.json())
  httpServer.use('/', Router)

  httpServer.use(function (err, req, res, next) {
    errHandler(err, res)
  })

  httpServer.listen(port, () => {
    logger.log(`alphaone sign app listening at http://localhost:${port}`)
  })
}

module.exports = {
  init
}
