const express = require('express')
const router = express.Router()
const Sign = require('../Sign')
const ResBody = require('../model/ResBody')
const { logger } = require('../logger/Index')
const gitCommitInfo = require('git-commit-info')
const aes256 = require('aes256')
const Props = require('../props/Index')

const wrapper = fn => (...args) => fn(...args).catch(args[2])

router.use(function timeLog (req, res, next) {
  const ds = Date.now()
  logger.info('callStart: ', ds)
  next()
  const de = Date.now()
  logger.info('callEnd: ', de, 'duriation: ', de - ds)
})

router.get('/', (req, res) => {
  res.json(ResBody.DEFAULT_OK({ service: 'Sign Service', version: '1.0' }))
})

router.get('/health', (req, res) => {
  res.json(ResBody.DEFAULT_OK({ git: gitCommitInfo() }))
})

router.post('/sign', (req, res, next) => {
  const {
    agent,
    body
  } = req.body
  const {
    mnemonic,
    userName,
    message,
    acctHash
  } = JSON.parse(aes256.decrypt(Props.getProp(agent + '.aes.key'), body))
  wrapper(Sign.signByMnemonicSync(message, mnemonic, userName, acctHash).then(signature => {
    res.json(ResBody.DEFAULT_OK({ sig: signature }))
  }))
})

module.exports = router
