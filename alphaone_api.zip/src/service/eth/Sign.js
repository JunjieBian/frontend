const fs = require('fs')
const readline = require('readline')
const Path = require('path')
const Account = require('./Account')
const ethers = require('ethers')
const Props = require('../../props/Index')

const abi = []

const processAbiFile = async () => {
  const fileStream = fs.createReadStream(Path.join(__dirname, '../../resources/eth.abi'))

  const rl = readline.createInterface({
    input: fileStream,
    crlfDelay: Infinity
  })

  for await (const line of rl) {
    console.log(`Line from file: ${line}`)
    abi.push(line)
  }
}

const init = async () => {
  await processAbiFile()
}

const signAndBroadCastSync = async (data, privateKey, contractAddress, key) => {
  if (abi.length === 0) {
    await processAbiFile()
  }
  const provider = new ethers.providers.JsonRpcProvider(Props.getProp('eth.json.rpc.provider.url'))
  const wallet = Account.getAcctByKeySync(privateKey, key, provider)
  const contract = new ethers.Contract(contractAddress, abi, provider)
  const contractWithSigner = contract.connect(wallet)
  const tx = await Reflect.apply(contractWithSigner[data.methodName], contractWithSigner, data.methodArgs)
  return Promise.resolve(tx)
}

module.exports = {
  init,
  signAndBroadCastSync
}
