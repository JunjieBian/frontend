const ethers = require('ethers')

const { logger } = require('../../logger/Index')
const Store = require('../../store/Index')

const createAcctByMnemonic = () => {
  const wallet = ethers.Wallet.createRandom()
  const randomMnemonic = wallet.mnemonic
  logger.info(randomMnemonic.phrase)
}

const getAcctByMnemonicSync = (mnemonic, key) => {
  if (Store.acctExist(key)) {
    return Store.getAcct(key)
  } else {
    const wallet = ethers.Wallet.fromMnemonic(mnemonic)
    Store.saveAcct(key, wallet)
    return wallet
  }
}

const getAcctByMnemonicAsync = (mnemonic, key) => {
  return new Promise((resolve, reject) => {
    if (Store.acctExist(key)) {
      return resolve(Store.getAcct(key))
    } else {
      const wallet = ethers.Wallet.fromMnemonic(mnemonic)
      Store.saveAcct(key, wallet)
      return resolve(wallet)
    }
  })
}

const getAcctByKeySync = (privateKey, key, provider) => {
  if (Store.acctExist(key)) {
    return Store.getAcct(key)
  } else {
    const wallet = new ethers.Wallet(privateKey, provider)
    Store.saveAcct(key, wallet)
    return wallet
  }
}

const getAcctByKeyAsync = (privateKey, key, provider) => {
  return new Promise((resolve, reject) => {
    if (Store.acctExist(key)) {
      return resolve(Store.getAcct(key))
    } else {
      const wallet = new ethers.Wallet(privateKey, provider)
      Store.saveAcct(key, wallet)
      return resolve(wallet)
    }
  })
}

module.exports = {
  getAcctByMnemonicSync,
  getAcctByMnemonicAsync,
  createAcctByMnemonic,
  getAcctByKeyAsync,
  getAcctByKeySync
}
