*** node版本： v10.16.3
//安装依赖
1. npm i

//启动Http服务
1. npm run http

//开发完代码后，运行
# npm run eslint
检查代码规范，修改警告，然后提交

//打包
1. npm install -g pkg
2. npm run packageW   --打包windows平台exe
2. npm run package   -- 打包linux平台可执行文件