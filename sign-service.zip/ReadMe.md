1. npm i


