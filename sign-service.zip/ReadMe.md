//安装依赖
1. npm i

//启动Http服务
2. npm run http
