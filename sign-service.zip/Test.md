curl -X POST -H "Content-Type: application/json" \
 --data '{"mnemonic":"mandate media town disagree sort skill mother ginger surround scrap ethics lady", "userName": "Adley","message":"test message","acctHash":"03d1ee15373de2c4084ac8caac5e9364"}' \
  http://localhost:3000/sign

curl -X POST -H "Content-Type: application/json" \
 --data '{"agent":"B01", "body": "BTnayciFdJsWVIxpcMKjAmWK1iBtqecteqeT6nbVxbTTlO6N+mC4aUg60ROXDA9WfWUX7WmXS7eKLavrVZ08G7f5vUnvzpXg8+UE0iROjZs4/Ufi+pspbLVFF+ydZOjb/EggcI/soqQm5Zgq6AYKoE3TI++aXEGnsnF7Zg0jnw67GxtHw8zfyM4u5ll+wkc6A0ui00UF21LGonPSYEMV+r+OdXvc3OQiIgulslmmo8l+PTr7KwFbow0K5WTk/dUHjsdV7/umsVA="}' \
  http://localhost:3000/sign

