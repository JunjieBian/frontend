curl -X POST -H "Content-Type: application/json" \
 --data '{"mnemonic":"mandate media town disagree sort skill mother ginger surround scrap ethics lady", "userName": "Adley","message":"test message","agent":"03d1ee15373de2c4084ac8caac5e9364"}' \
  http://localhost:3000/sign

curl -X POST -H "Content-Type: application/json" \
  http://localhost:3000/sign