const express = require('express')
const Router = require('./Router')
const httpServer = express()
const bodyParser = require('body-parser')

const init = (port = 3000) => {
  httpServer.use(bodyParser.json())
  httpServer.use('/', Router)

  httpServer.use(function (err, req, res, next) {
    console.error('err.stack = ', err.stack)
    res.status(500).send(err.message)
  })

  httpServer.listen(port, () => {
    console.log(`Example app listening at http://localhost:${port}`)
  })
}

module.exports = {
  init
}
