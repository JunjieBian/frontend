const express = require('express')
const router = express.Router()
const Sign = require('../Sign')
const ResBody = require('./model/ResBody')

// const serviceMiddleware = fn =>
//   (req, res, next) => {
//     Promise.resolve(fn(req, res, next))
//       .catch(err => {
//         console.log('err = ', err)
//         next(err)
//       })
//   }
const errHandler = (err, res) => {
  console.error('err.stack = ', err.stack)
  res.status(500).json(ResBody.DEFAULT_ERR(err.message))
}

router.use(function timeLog (req, res, next) {
  const ds = Date.now()
  console.info('callStart: ', ds)
  next()
  const de = Date.now()
  console.info('callEnd: ', de, 'duriation: ', de - ds)
})

router.get('/', (req, res) => {
  res.json({ service: 'Sign Service', version: '1.0' })
})

router.post('/sign', (req, res, next) => {
  console.info(req.body)
  const {
    mnemonic,
    userName,
    message,
    agent
  } = req.body
  Sign.signByMnemonicSync(message, mnemonic, userName, agent).then(signature => {
    res.json({ signature: signature })
  }).catch(er => errHandler(er, res))
})

module.exports = router
