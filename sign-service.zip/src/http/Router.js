const express = require('express')
const router = express.Router()
const Sign = require('../Sign')
const ResBody = require('../model/ResBody')
const { logger } = require('../logger/Index')
const gitCommitInfo = require('git-commit-info')
const aes256 = require('aes256')
const Props = require('../props/Index')

// const serviceMiddleware = fn =>
//   (req, res, next) => {
//     Promise.resolve(fn(req, res, next))
//       .catch(err => {
//         console.log('err = ', err)
//         next(err)
//       })
//   }
const errHandler = (err, res) => {
  logger.error('err.stack = ', err.stack)
  res.status(500).json(ResBody.DEFAULT_ERR(err.message))
}

router.use(function timeLog (req, res, next) {
  const ds = Date.now()
  logger.info('callStart: ', ds)
  next()
  const de = Date.now()
  logger.info('callEnd: ', de, 'duriation: ', de - ds)
})

router.get('/', (req, res) => {
  res.json(ResBody.DEFAULT_OK({ service: 'Sign Service', version: '1.0' }))
})

router.get('/health', (req, res) => {
  res.json(ResBody.DEFAULT_OK({ git: gitCommitInfo() }))
})

router.post('/sign', (req, res, next) => {
  const {
    agent,
    body
  } = req.body
  const {
    mnemonic,
    userName,
    message,
    acctHash
  } = JSON.parse(aes256.decrypt(Props.getProp(agent + '.aes.key'), body))
  Sign.signByMnemonicSync(message, mnemonic, userName, acctHash).then(signature => {
    res.json(ResBody.DEFAULT_OK({ sig: signature }))
  }).catch(er => errHandler(er, res))
})

module.exports = router
