const { uuid } = require('uuidv4')

module.exports = class ReqBody {
  constructor (requrestId = uuid().replaceAll('-',''), agent = '', authPwd = '', body = {}) {
    this.requrestId = requrestId
    this.agent = agent
    this.authPwd = authPwd
    this.body = body
  }
  get agent() {
    return this.agent
  }
  get authPwd() {
    return this.authPwd
  }
  get body(){
    return this.body
  }
}
