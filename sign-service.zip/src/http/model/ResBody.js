module.exports = class ResBody {
  constructor (code = 200, msg = 'OK', data = {}) {
    this.code = code
    this.msg = msg
    this.data = data
  }

  static DEFAULT_ERR (msg) {
    return new ResBody(500, msg)
  }

  static DEFAULT_OK (param) {
    return new ResBody(200, ...param)
  }
}
