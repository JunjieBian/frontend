const HttpServer = require('./http/Server')

const APP = () => {
  const args = [...process.argv]
  if (args[2] === 'HTTP') {
    HttpServer.init()
  }
  if (args[2] === 'WSS') {
    HttpServer.init()
  }
}

console.log('process.env.net = ', process.env.net)
APP()
