const Props = require('./props/Index')
const HttpServer = require('./http/Server')
const { logger } = require('./logger/Index')

const APP = () => {
  const args = [...process.argv]
  logger.info(args)
  if (args[2].toUpperCase() === 'HTTP') {
    return HttpServer.init()
  }
  if (args[2].toUpperCase() === 'WSS') {
    //待开发
    logger.warn('websocket待开发。。。')
    process.exit(0)
  }
  logger.error('用法： npm run http | wss')
}

APP()
