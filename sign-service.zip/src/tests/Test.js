const Md5 = require('md5')
const Sign = require('../Sign')
const { uuid } = require('uuidv4')
const gitCommitInfo = require('git-commit-info')

const mnemonic = 'mandate media town disagree sort skill mother ginger surround scrap ethics lady'
const userNme = 'Adley'

const acctHash = Md5(userNme + mnemonic)

console.log(gitCommitInfo())
