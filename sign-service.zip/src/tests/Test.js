const Md5 = require('md5')
const Sign = require('../Sign')
const { uuid } = require('uuidv4')
const gitCommitInfo = require('git-commit-info')
const { logger } = require('../logger/Index')
const aes256 = require('aes256')
const Props = require('../props/Index')

const mnemonic = 'mandate media town disagree sort skill mother ginger surround scrap ethics lady'
const userNme = 'Adley'

const acctHash = Md5(userNme + mnemonic)

logger.info(typeof '' === 'object')

const reqId = uuid()
console.log(uuid().replace(/-/g,''))


const body = {"mnemonic":"mandate media town disagree sort skill mother ginger surround scrap ethics lady", "userName": "Adley","message":"test message","acctHash":"03d1ee15373de2c4084ac8caac5e9364"}

console.log(aes256.encrypt(Props.getProp('B01.aes.key'), JSON.stringify(body)))
