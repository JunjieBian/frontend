const Md5 = require('md5')
const Sign = require('../Sign')

const mnemonic = 'mandate media town disagree sort skill mother ginger surround scrap ethics lady'
const userNme = 'Adley'

const agent = Md5(userNme + mnemonic)

const url = 'http://localhost:3000'

// test("", () => {
//   expect(Curl.postJSON(url + '/sign', signBody)).not.toBeNull()
// })
