const state = {
  acctMap: new Map()
}

module.exports = {
  acctExist (key) {
    return state.acctMap.has(key)
  },
  getAcct (key) {
    return state.acctMap.get(key)
  },
  saveAcct (key, pair) {
    state.acctMap.set(key, pair)
  }
}
