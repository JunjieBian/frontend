const log4js = require('log4js')
const os = require('os')

const Props = require('../props/Index')

log4js.addLayout('json', function (config) {
  return function (logEvent) { return JSON.stringify(logEvent) + config.separator }
})

log4js.configure({
  appenders: {
    file: {
      type: 'dateFile',
      layout: { type: 'json', separator: os.EOL },
      keepFileExt: true,
      daysToKeep: 7,
      filename: `${Props.getProp('log.home')}/public_sign_service_logger.log`
    },
    console: {
       type: 'stdout',
        layout: { 
          type: 'pattern', 
          pattern: '%d{yyyy-MM-dd hh:mm:ss.sss} [%p][%f{2}(%l)] ===> %[%m]%' } }
  },
  categories: {
    default: { appenders: ['file', 'console'], level: 'info', enableCallStack: true }
  }
})
const logger = log4js.getLogger()

module.exports = {
  logger
}
