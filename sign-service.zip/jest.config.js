module.exports = {
  verbose: true,
  rootDir: process.env.pwd,
  testMatch: ['<rootDir>/src/tests/*.js']
}
